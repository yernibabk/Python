def get_lines(filename):
    """ Reads the contents of filename
        and returns the - File handle
        - List of all lines of the file
    """
    ## Your implementation goes here ###


def write_lines(filename, lines):
    """ Writes the lines into the a file whose
        filename is given as argument
    """
    ## Your implementation goes here ###
