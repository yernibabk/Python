#!/usr/bin/python3
"""
    This is a sample program that helps understand
    comparison of strings
"""

def main():
    left = "night"
    right = "day"
    if left > right:
        print(left, "wins")
    else:
        print(right, "wins")

# Main starts from here
main()
