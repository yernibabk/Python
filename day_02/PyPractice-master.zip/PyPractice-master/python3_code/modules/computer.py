import add

print("Computer")
x, y = add.get_input()
add.do_mul(x, y)
print("Bye")
