#!/usr/bin/python
""" This is my first Python program
    This prompts the user to enter his name and then
    welcomes the user by printing "Hello" followed by his name
"""

name = input("Enter your name : ")
print("Hello", name, "!!!")
